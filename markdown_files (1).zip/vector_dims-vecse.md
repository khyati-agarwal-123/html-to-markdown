[Previous](vector_dimension_count-vecse.md) [Next](vector_dimension_format-
vecse.md) JavaScript must be enabled to correctly display this content

  1. [Oracle AI Vector Search User's Guide](index.md)
  2. [Use SQL Functions for Vector Operations](use-sql-functions-vector-operations.md)
  3. [Constructors, Converters, and Descriptors](constructors-converters-descriptors-and-arithmetic-functions.md)
  4. VECTOR_DIMS

## VECTOR_DIMS

`VECTOR_DIMS` returns the number of dimensions of a vector as a `NUMBER`.
`VECTOR_DIMS` is synonymous with `VECTOR_DIMENSION_COUNT`.

Syntax

  

![Description of vector_dims.eps
follows](https://docs.oracle.com/en/database/oracle/oracle-database/23/vecse/img/vector_dims.gif)  
[Description of the illustration vector_dims.eps](img_text/vector_dims.md)

  

Purpose

Refer to [VECTOR_DIMENSION_COUNT](vector_dimension_count-
vecse.md#GUID-1506357D-AE4E-41F1-8476-BED1BC824230 "VECTOR_DIMENSION_COUNT
returns the number of dimensions of a vector as a NUMBER.") for full
semantics.

**Parent topic:** [Constructors, Converters, and Descriptors](constructors-
converters-descriptors-and-arithmetic-functions.md "Other basic vector
operations for Oracle AI Vector Search involve creating, converting, and
describing vectors.")


[← Previous](vector_dimension_count-vecse.md)

[Next →](vector_dimension_format-vecse.md)
