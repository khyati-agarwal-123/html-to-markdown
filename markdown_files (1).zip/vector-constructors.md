[Previous](constructors-converters-descriptors-and-arithmetic-functions.md)
[Next](to_vector-vecse.md) JavaScript must be enabled to correctly display
this content

  1. [Oracle AI Vector Search User's Guide](index.md)
  2. [Use SQL Functions for Vector Operations](use-sql-functions-vector-operations.md)
  3. [Constructors, Converters, and Descriptors](constructors-converters-descriptors-and-arithmetic-functions.md)
  4. Vector Constructors

## Vector Constructors

`TO_VECTOR()` and `VECTOR()` are synonymous constructors of vectors. The
functions take a string of type `VARCHAR2` or `CLOB` as input and return a
vector as output.

  * [TO_VECTOR](to_vector-vecse.md)  
`TO_VECTOR` is a constructor that takes a string of type `VARCHAR2` or `CLOB`
as input, converts it to a vector, and returns a vector as output. `TO_VECTOR`
also takes another vector as input, adjusts its format, and returns the
adjusted vector as output. `TO_VECTOR` is synonymous with `VECTOR`.

  * [VECTOR](vector-vecse.md)  
`VECTOR` is a constructor that takes a string of type `VARCHAR2` or `CLOB` as
input and returns a vector as output. `VECTOR` is synonymous with `TO_VECTOR`.

**Parent topic:** [Constructors, Converters, and Descriptors](constructors-
converters-descriptors-and-arithmetic-functions.md "Other basic vector
operations for Oracle AI Vector Search involve creating, converting, and
describing vectors.")


[← Previous](constructors-converters-descriptors-and-arithmetic-functions.md)

[Next →](to_vector-vecse.md)
