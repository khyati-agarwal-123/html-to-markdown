[Previous](unload-and-load-vectors-using-oracle-data-pump.md) [Next](size-
vector-pool.md) JavaScript must be enabled to correctly display this content

  1. [Oracle AI Vector Search User's Guide](index.md)
  2. Create Vector Indexes

## 6 Create Vector Indexes

You may want to create vector indexes on your vector embeddings and use these
indexes for running similarity searches over huge vector spaces.

Vector indexes are a class of specialized indexing data structures that are
designed to accelerate similarity searches using high-dimensional vectors.
They use techniques such as clustering, partitioning, and neighbor graphs to
group vectors representing similar items, which drastically reduces the search
space, thereby making the search process extremely efficient.

  * [Size the Vector Pool](size-vector-pool.md)  
To allow vector index creation, you must enable a new memory area stored in
the SGA called the **Vector Pool**.

  * [Manage the Different Categories of Vector Indexes](manage-different-categories-vector-indexes.md)  
Learn how vector indexing methods make vector searches faster and how to
enable vector indexes creation.


[← Previous](unload-and-load-vectors-using-oracle-data-pump.md)

[Next →](size-vector-pool.md)
