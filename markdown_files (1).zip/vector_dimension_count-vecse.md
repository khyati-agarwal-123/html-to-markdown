[Previous](vector_norm-vecse.md) [Next](vector_dims-vecse.md) JavaScript
must be enabled to correctly display this content

  1. [Oracle AI Vector Search User's Guide](index.md)
  2. [Use SQL Functions for Vector Operations](use-sql-functions-vector-operations.md)
  3. [Constructors, Converters, and Descriptors](constructors-converters-descriptors-and-arithmetic-functions.md)
  4. VECTOR_DIMENSION_COUNT

## VECTOR_DIMENSION_COUNT

`VECTOR_DIMENSION_COUNT` returns the number of dimensions of a vector as a
`NUMBER`.

Syntax

  

![Description of vector_dimension_count.eps
follows](https://docs.oracle.com/en/database/oracle/oracle-database/23/vecse/img/vector_dimension_count.gif)  
[Description of the illustration
vector_dimension_count.eps](img_text/vector_dimension_count.md)

  

Purpose

`VECTOR_DIMENSION_COUNT` is synonymous with [VECTOR_DIMS](vector_dims-
vecse.md#GUID-73D916C1-5ABE-4ED2-9BB6-018AF4540C62 "VECTOR_DIMS returns the
number of dimensions of a vector as a NUMBER. VECTOR_DIMS is synonymous with
VECTOR_DIMENSION_COUNT.").

Parameters

`expr` must evaluate to a vector.

If `expr` is NULL, NULL is returned.

Example

    
    
    SELECT VECTOR_DIMENSION_COUNT( TO_VECTOR('[34.6, 77.8]', 2, FLOAT64) );
    VECTOR_DIMENSION_COUNT(TO_VECTOR('[34.6,77.8]',2,FLOAT64))
    ----------------------------------------------------------                           
    

**Parent topic:** [Constructors, Converters, and Descriptors](constructors-
converters-descriptors-and-arithmetic-functions.md "Other basic vector
operations for Oracle AI Vector Search involve creating, converting, and
describing vectors.")


[← Previous](vector_norm-vecse.md)

[Next →](vector_dims-vecse.md)
