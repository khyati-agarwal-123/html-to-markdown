[Previous](index-accuracy-report.md) [Next](vector-distance-functions-and-
operators.md) JavaScript must be enabled to correctly display this content

  1. [Oracle AI Vector Search User's Guide](index.md)
  2. Use SQL Functions for Vector Operations

## 7 Use SQL Functions for Vector Operations

There are a number of SQL functions and operators that you can use with
vectors in Oracle AI Vector Search.

  * [Vector Distance Functions and Operators](vector-distance-functions-and-operators.md)  
A vector distance function takes in two vector operands and a distance metric
to compute a mathematical distance between those two vectors, based on the
distance metric provided. You can optionally use shorthand distance functions
and operators instead of their corresponding distance functions.

  * [Chunking and Vector Generation Functions](chunking-and-vector-generation-functions.md)  
Oracle AI Vector Search offers Vector Utilities, which provide the
`VECTOR_CHUNKS` and `VECTOR_EMBEDDING` SQL functions for chunking data and
generating vector embedding, respectively.

  * [Constructors, Converters, and Descriptors](constructors-converters-descriptors-and-arithmetic-functions.md)  
Other basic vector operations for Oracle AI Vector Search involve creating,
converting, and describing vectors.

  * [JSON Compatibility with the VECTOR Data Type](json-compatibility-vector-data-type.md)  
The JSON data type supports the `VECTOR` type as a JSON scalar type. A
`VECTOR` instance is convertible to a JSON type instance and vice versa using
the JSON constructor and the `VECTOR` constructor, respectively.


[← Previous](index-accuracy-report.md)

[Next →](vector-distance-functions-and-operators.md)
