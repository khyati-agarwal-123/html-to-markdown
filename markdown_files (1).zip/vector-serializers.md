[Previous](vector-vecse.md) [Next](from_vector-vecse.md) JavaScript must
be enabled to correctly display this content

  1. [Oracle AI Vector Search User's Guide](index.md)
  2. [Use SQL Functions for Vector Operations](use-sql-functions-vector-operations.md)
  3. [Constructors, Converters, and Descriptors](constructors-converters-descriptors-and-arithmetic-functions.md)
  4. Vector Serializers

## Vector Serializers

`FROM_VECTOR()` and `VECTOR_SERIALIZE()` are synonymous serializers of
vectors. The functions take a vector as input and return a string of type
`VARCHAR2` or `CLOB` as output.

  * [FROM_VECTOR](from_vector-vecse.md)  
`FROM_VECTOR` takes a vector as input and returns a string of type `VARCHAR2`
or `CLOB` as output.

  * [VECTOR_SERIALIZE](vector_serialize-vecse.md)  
`VECTOR_SERIALIZE` is synonymous with `FROM_VECTOR.`

**Parent topic:** [Constructors, Converters, and Descriptors](constructors-
converters-descriptors-and-arithmetic-functions.md "Other basic vector
operations for Oracle AI Vector Search involve creating, converting, and
describing vectors.")


[← Previous](vector-vecse.md)

[Next →](from_vector-vecse.md)
