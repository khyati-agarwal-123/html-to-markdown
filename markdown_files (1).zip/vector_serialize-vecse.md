[Previous](from_vector-vecse.md) [Next](vector_norm-vecse.md) JavaScript
must be enabled to correctly display this content

  1. [Oracle AI Vector Search User's Guide](index.md)
  2. [Use SQL Functions for Vector Operations](use-sql-functions-vector-operations.md)
  3. [Constructors, Converters, and Descriptors](constructors-converters-descriptors-and-arithmetic-functions.md)
  4. [Vector Serializers](vector-serializers.md)
  5. VECTOR_SERIALIZE

## VECTOR_SERIALIZE

`VECTOR_SERIALIZE` is synonymous with `FROM_VECTOR.`

Syntax

  

![Description of vector_serialize.eps
follows](https://docs.oracle.com/en/database/oracle/oracle-database/23/vecse/img/vector_serialize.gif)  
[Description of the illustration
vector_serialize.eps](img_text/vector_serialize.md)

  

Purpose

See [FROM_VECTOR](from_vector-vecse.md#GUID-
DA483A01-340D-4D7C-BD07-7ECFB830B595 "FROM_VECTOR takes a vector as input and
returns a string of type VARCHAR2 or CLOB as output.") for semantics and
examples.

Examples

    
    
    SELECT VECTOR_SERIALIZE(VECTOR('[1.1,2.2,3.3]',3,FLOAT32));
    
    
    VECTOR_SERIALIZE(VECTOR('[1.1,2.2,3.3]',3,FLOAT32))
    ---------------------------------------------------------------
    [1.10000002E+000,2.20000005E+000,3.29999995E+000]
    
    1 row selected.
    
    
    
    SELECT VECTOR_SERIALIZE(VECTOR('[1.1, 2.2, 3.3]',3,FLOAT32) RETURNING VARCHAR2(1000));
    
    
    VECTOR_SERIALIZE(VECTOR('[...]',3,FLOAT32)RETURNINGVARCHAR2(1000))
    ------------------------------------------------------------------
    [1.10000002E+000,2.20000005E+000,3.29999995E+000]
    
    1 row selected.
    
    
    SELECT VECTOR_SERIALIZE(VECTOR('[1.1, 2.2, 3.3]',3,FLOAT32) RETURNING CLOB);
    
    
    VECTOR_SERIALIZE(VECTOR('[1.1, 2.2, 3.3]',3,FLOAT32)RETURNINGCLOB)
    --------------------------------------------------------
    [1.10000002E+000,2.20000005E+000,3.29999995E+000] 
    
    1 row selected.
    

**Parent topic:** [Vector Serializers](vector-serializers.md
"FROM_VECTOR\(\) and VECTOR_SERIALIZE\(\) are synonymous serializers of
vectors. The functions take a vector as input and return a string of type
VARCHAR2 or CLOB as output.")


[← Previous](from_vector-vecse.md)

[Next →](vector_norm-vecse.md)
