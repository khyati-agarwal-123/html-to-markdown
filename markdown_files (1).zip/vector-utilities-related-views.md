[Previous](oracle-ai-vector-search-views.md)
[Next](all_vector_abbrev_tokens.md) JavaScript must be enabled to correctly
display this content

  1. [Oracle AI Vector Search User's Guide](index.md)
  2. [Vector Diagnostics](vector-diagnostics-node.md)
  3. [Oracle AI Vector Search Views](oracle-ai-vector-search-views.md)
  4. Vector Utilities-Related Views

## Vector Utilities-Related Views

These views display language-specific data (abbreviation token details) and
vocabulary data related to the Oracle AI Vector Search SQL and PL/SQL
utilities.

  * [ALL_VECTOR_ABBREV_TOKENS](all_vector_abbrev_tokens.md)  
The `ALL_VECTOR_ABBREV_TOKENS` view displays a list of abbreviation tokens
from all supported languages.

  * [ALL_VECTOR_LANG](all_vector_lang.md)  
The `ALL_VECTOR_LANG` view displays a list of all supported languages,
distributed by default.

  * [USER_VECTOR_ABBREV_TOKENS](user_vector_abbrev_tokens.md)  
The `USER_VECTOR_ABBREV_TOKENS` view displays a list of abbreviation tokens
from all languages loaded by the current user.

  * [USER_VECTOR_LANG](user_vector_lang.md)  
The `USER_VECTOR_LANG` view displays all languages loaded by the current user.

  * [USER_VECTOR_VOCAB](user_vector_vocab.md)  
The `USER_VECTOR_VOCAB` view displays all custom token vocabularies created by
the current user.

  * [USER_VECTOR_VOCAB_TOKENS](user_vector_vocab_tokens.md)  
The `USER_VECTOR_VOCAB_TOKENS` view displays tokens from all custom token
vocabularies created by the current user.

  * [ALL_VECTOR_VOCAB](all_vector_vocab.md)  
The `ALL_VECTOR_VOCAB` view displays all custom token vocabularies.

  * [ALL_VECTOR_VOCAB_TOKENS](all_vector_vocab_tokens.md)  
The `ALL_VECTOR_VOCAB_TOKENS` view displays tokens from all custom token
vocabularies.

**Related Topics**

  * [Oracle Database PL/SQL Packages and Types Reference](/pls/topic/lookup?ctx=en/database/oracle/oracle-database/23/vecse&id=ARPLS-GUID-99AB8D7F-00A7-4299-B9F8-AA9A1CE0854D)

**Parent topic:** [Oracle AI Vector Search Views](oracle-ai-vector-search-
views.md "These are a set of data dictionary views related to Oracle AI
Vector Search.")


[← Previous](oracle-ai-vector-search-views.md)

[Next →](all_vector_abbrev_tokens.md)
