[Previous](generate-and-use-embeddings-end-end-search.md) [Next](explore-
chunking-techniques-and-examples.md) JavaScript must be enabled to correctly
display this content

  1. [Oracle AI Vector Search User's Guide](index.md)
  2. [Generate Vector Embeddings](generate-vector-embeddings-node.md)
  3. [Vector Generation Examples](vector-generation-examples.md)
  4. Configure Chunking Parameters

## Configure Chunking Parameters

Oracle AI Vector Search provides many parameters for chunking text data. In
these examples, you can see how to configure these parameters to define your
own chunking specifications and strategies.

Chunking prepares your unstructured data to ensure that it is in a format that
can be processed by vector embedding models.

  * [Explore Chunking Techniques and Examples](explore-chunking-techniques-and-examples.md)  
Review these examples of all the supported chunking parameters. These examples
can provide an idea on what are good and bad chunking techniques, and thus
help you define a strategy when chunking your data.

  * [Create and Use Custom Vocabulary](create-and-use-custom-vocabulary.md)  
Create and use your own vocabulary of tokens when chunking data.

  * [Create and Use Custom Language Data](create-and-use-custom-language-data.md)  
Create and use your own language-specific conditions (such as common
abbreviations) when chunking data.

**Parent topic:** [Vector Generation Examples](vector-generation-examples.md
"Run these end-to-end examples to see how you can generate vector embeddings,
both within and outside the database.")


[← Previous](generate-and-use-embeddings-end-end-search.md)

[Next →](explore-chunking-techniques-and-examples.md)
