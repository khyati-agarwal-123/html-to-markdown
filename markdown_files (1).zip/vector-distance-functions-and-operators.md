[Previous](use-sql-functions-vector-operations.md) [Next](vector-distance-
metrics.md) JavaScript must be enabled to correctly display this content

  1. [Oracle AI Vector Search User's Guide](index.md)
  2. [Use SQL Functions for Vector Operations](use-sql-functions-vector-operations.md)
  3. Vector Distance Functions and Operators

## Vector Distance Functions and Operators

A vector distance function takes in two vector operands and a distance metric
to compute a mathematical distance between those two vectors, based on the
distance metric provided. You can optionally use shorthand distance functions
and operators instead of their corresponding distance functions.

Distances determine similarity or dissimilarity between vectors.

  * [Vector Distance Metrics](vector-distance-metrics.md)  
Measuring distances in a vector space is at the heart of identifying the most
relevant results for a given query vector. That process is very different from
the well-known keyword filtering in the relational database world.

  * [VECTOR_DISTANCE](vector_distance-vecse.md)  
`VECTOR_DISTANCE` is the main function that you can use to calculate the
distance between two vectors.

  * [L1_DISTANCE](l1_distance-vecse.md)  
`L1_DISTANCE` is a shorthand version of the `VECTOR_DISTANCE` function that
calculates the distance between two vectors. It takes two vectors as input and
returns the distance between them as a `BINARY_DOUBLE`.

  * [L2_DISTANCE](l2_distance-vecse.md)  
`L2_DISTANCE` is a shorthand version of the `VECTOR_DISTANCE` function that
calculates the distance between two vectors. It takes two vectors as input and
returns the distance between them as a `BINARY_DOUBLE`.

  * [COSINE_DISTANCE](cosine_distance-vecse.md)  
`COSINE_DISTANCE` is a shorthand version of the `VECTOR_DISTANCE` function
that calculates the distance between two vectors. It takes two vectors as
input and returns the distance between them as a `BINARY_DOUBLE`.

  * [INNER_PRODUCT](inner_product-vecse.md)  
`INNER_PRODUCT` is a shorthand version of the `VECTOR_DISTANCE` function that
calculates the distance between two vectors. It takes two vectors as input and
returns the distance between them as a `BINARY_DOUBLE`.

**Related Topics**

  * [Perform Exact Similarity Search](perform-exact-similarity-search.md#GUID-CCCF06F5-AD46-466D-99B2-4609B84C2B69 "A similarity search looks for the relative order of vectors compared to a query vector. Naturally, the comparison is done using a particular distance metric but what is important is the result set of your top closest vectors, not the distance between them.")
  * [Perform Approximate Similarity Search Using Vector Indexes](perform-approximate-similarity-search-using-vector-indexes.md#GUID-D8432ADA-38B0-4E5F-975F-E86977CA8488 "For a vector search to be useful, it needs to be fast and accurate. Approximate similarity searches seek a balance between these goals.")

**Parent topic:** [Use SQL Functions for Vector Operations](use-sql-functions-
vector-operations.md "There are a number of SQL functions and operators that
you can use with vectors in Oracle AI Vector Search.")


[← Previous](use-sql-functions-vector-operations.md)

[Next →](vector-distance-metrics.md)
