[Previous](generate-text-using-public-third-party-apis.md) [Next](retrieval-
augmented-generation1.md) JavaScript must be enabled to correctly display
this content

  1. [Oracle AI Vector Search User's Guide](index.md)
  2. [Work with LLM-Powered APIs and Retrieval Augmentation Generation](work-llm-powered-apis-and-retrieval-augmentation-generation-node.md)
  3. Use Retrieval Augmented Generation to Complement LLMs

## Use Retrieval Augmented Generation to Complement LLMs

RAG lets you mitigate the inaccuracies and hallucinations faced when using
LLMs. Oracle AI Vector Search enables RAG within Oracle Database using the
`DBMS_VECTOR_CHAIN` PL/SQL package or through popular frameworks (such as
LangChain).

  * [About Retrieval Augmented Generation](retrieval-augmented-generation1.md)  
Oracle AI Vector Search supports Enterprise Retrieval Augmented Generation
(RAG) to enable sophisticated queries that can combine vectors with relational
data, graph data, spatial data, and JSON collections.

  * [SQL RAG Example](sql-rag-example.md)  
This scenario allows you to run a similarity search for specific documentation
content based on a user query. Once documentation chunks are retrieved, they
are concatenated and a prompt is generated to ask an LLM to answer the user
question using retrieved chunks.

**Parent topic:** [Work with LLM-Powered APIs and Retrieval Augmentation
Generation](work-llm-powered-apis-and-retrieval-augmentation-generation-
node.md "You can use Vector Utility PL/SQL APIs for prompting Large Language
Models \(LLMs\) with textual prompts, using LLM-powered chat interfaces. You
can also communicate with LLMs through the implementation of Retrieval
Augmentation Generation \(RAG\), which helps to generate more accurate and
informative responses.")


[← Previous](generate-text-using-public-third-party-apis.md)

[Next →](retrieval-augmented-generation1.md)
