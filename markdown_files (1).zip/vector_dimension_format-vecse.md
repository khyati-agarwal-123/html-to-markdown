[Previous](vector_dims-vecse.md) [Next](json-compatibility-vector-data-
type.md) JavaScript must be enabled to correctly display this content

  1. [Oracle AI Vector Search User's Guide](index.md)
  2. [Use SQL Functions for Vector Operations](use-sql-functions-vector-operations.md)
  3. [Constructors, Converters, and Descriptors](constructors-converters-descriptors-and-arithmetic-functions.md)
  4. VECTOR_DIMENSION_FORMAT

## VECTOR_DIMENSION_FORMAT

`VECTOR_DIMENSION_FORMAT` returns the storage format of the vector. It returns
a `VARCHAR2`, which can be one of the following values: `INT8`, `FLOAT32`, or
`FLOAT64`.

Syntax

  

![Description of vector_dimension_format.eps
follows](https://docs.oracle.com/en/database/oracle/oracle-database/23/vecse/img/vector_dimension_format.gif)  
[Description of the illustration
vector_dimension_format.eps](img_text/vector_dimension_format.md)

  

Parameters

`expr` must evaluate to a vector.

If `expr` is NULL, NULL is returned.

Examples

    
    
    SELECT VECTOR_DIMENSION_FORMAT(TO_VECTOR('[34.6, 77.8]', 2, FLOAT64));
    FLOAT64
    
    SELECT VECTOR_DIMENSION_FORMAT(TO_VECTOR('[34.6, 77.8, 9]', 3, FLOAT32));
    FLOAT32
    
    SELECT VECTOR_DIMENSION_FORMAT(TO_VECTOR('[34.6, 77.8, 9, 10]', 3, INT8));
    SELECT VECTOR_DIMENSION_FORMAT(TO_VECTOR('[34.6, 77.8, 9, 10]', 3, INT8))                           
                                                                            *
    ERROR at line 1:
    ORA-51803: Vector dimension count must match the dimension count specified inthe column definition (actual: 4, required: 3).
    
    SELECT VECTOR_DIMENSION_FORMAT(TO_VECTOR('[34.6, 77.8, 9.10]', 3, INT8));
    VECTOR_DIMENSION_FORMAT(TO_VECTOR('[34.6,77.8,9.10
    --------------------------------------------------
    INT8
    
    SELECT TO_VECTOR('[34.6, 77.8, 9.10]', 3, INT8);
    TO_VECTOR('[34.6,77.8,9.10]',3,INT8)
    ---------------------------------------------------
    [3.5E+001,7.8E+001,9.0E+000]
    

**Parent topic:** [Constructors, Converters, and Descriptors](constructors-
converters-descriptors-and-arithmetic-functions.md "Other basic vector
operations for Oracle AI Vector Search involve creating, converting, and
describing vectors.")


[← Previous](vector_dims-vecse.md)

[Next →](json-compatibility-vector-data-type.md)
