[Previous](june-2024-autonomous-database.md) [Next](july-2024-autonomous-
database.md) JavaScript must be enabled to correctly display this content

  1. [Oracle AI Vector Search User's Guide](index.md)
  2. [What's New for Oracle AI Vector Search](whats-new-oracle-ai-vector-search.md)
  3. July 2024 Oracle Database 23ai, Release Update 23.5

## July 2024 Oracle Database 23ai, Release Update 23.5

Included are some notable Oracle AI Vector Search updates with Oracle Database
23ai, Release Update 23.5.

Feature | Description  
---|---  
Binary Vectors |  You can use the `BINARY` vector dimension format to declare vectors and vector columns.  For more information, see [Create Tables Using the VECTOR Data Type](create-tables-using-vector-data-type.md#GUID-E05AC257-CBD6-4B0C-A29F-0116EF02EA3A "You can declare a table's column as a VECTOR data type.").   
  
**Parent topic:** [What's New for Oracle AI Vector Search](whats-new-oracle-
ai-vector-search.md)


[← Previous](june-2024-autonomous-database.md)

[Next →](july-2024-autonomous-database.md)
