[Previous](vector-generation-examples.md) [Next](convert-text-string-
embedding-and-oracle-database.md) JavaScript must be enabled to correctly
display this content

  1. [Oracle AI Vector Search User's Guide](index.md)
  2. [Generate Vector Embeddings](generate-vector-embeddings-node.md)
  3. [Vector Generation Examples](vector-generation-examples.md)
  4. Generate Embeddings

## Generate Embeddings

In these examples, you can see how to generate one or more vector embeddings
from an input text string.

The resulting embeddings are vector representations of the input data, and
capture the semantic meaning or context of that data.

  * [Convert Text String to Embedding Within and Outside Oracle Database](convert-text-string-embedding-and-oracle-database.md)  
Perform a text-to-embedding transformation by accessing either a vector
embedding model in ONNX format (stored in the database) or a third-party
vector embedding model.

  * [Convert Text String to BINARY Embedding Outside Oracle Database](convert-text-string-binary-embedding-oracle-database.md)  
Perform a text-to-`BINARY`-embedding transformation by accessing a third-party
`BINARY` vector embedding model.

**Parent topic:** [Vector Generation Examples](vector-generation-examples.md
"Run these end-to-end examples to see how you can generate vector embeddings,
both within and outside the database.")


[← Previous](vector-generation-examples.md)

[Next →](convert-text-string-embedding-and-oracle-database.md)
