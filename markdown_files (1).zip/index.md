Previous [Next](preface.md) JavaScript must be enabled to correctly display
this content

  1. [Oracle AI Vector Search User's Guide](toc.htm)
  2. Oracle® Database

## Oracle® Database

Oracle AI Vector Search User's Guide

23ai

F87786-08

July 2024

* * *

Title and Copyright Information

Oracle Database Oracle AI Vector Search User's Guide, 23ai

F87786-08

[Copyright Â©](/pls/topic/lookup?ctx=en/legal&id=cpyr)2023,2024,

Oracle and/or its affiliates.

Primary Authors: Jean-Francois Verrier, Binika Kumar, Sarah Hirschfeld

Contributing Authors: Douglas Williams, Frederick Kush, Gunjan Jain, Jessica
True, Jody Glover, Maitreyee Chaliha, Mamata Basapur, Prakash Jashnani, Ramya
P, Sarika Surampudi, Suresh Rajan, Tulika Das, Usha Krishnamurthy

Contributors: Aleksandra Czarlinska, Agnivo Saha, Angela Amor, Aurosish
Mishra, Bonnie Xia, Boriana Milenova, David Jiang, Dinesh Das, Doug Hood,
George Krupka, Harichandan Roy, Malavika S P, Mark Hornick, Rohan Aggarwal,
Roger Ford, Sebastian DeLaHoz, Shasank Chavan, Tirthankar Lahiri, Teck Hua
Lee, Valentin Leonard Tabacaru Cristache, Vinita Subramanian, Weiwei Gong,
Yuan Zhou


[← Previous](preface.md)

[Next →](preface.html#GUID-CD072352-2A53-4F83-8009-F375A6FBDB41)
